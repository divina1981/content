"use client";

import { useRef } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { episodes, getEpisodeBySlug, SERIES_INFO } from "@/lib/series";
import { useProgress } from "@/lib/useProgress";

export default function EpisodePage() {
  const { slug } = useParams<{ slug: string }>();
  const episode = getEpisodeBySlug(slug);
  const { toggle, isLearned } = useProgress();

  if (!episode) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Episode not found.</p>
      </div>
    );
  }

  const prevEp = episodes.find((e) => e.week === episode.week - 1);
  const nextEp = episodes.find((e) => e.week === episode.week + 1);

  return (
    <div className="min-h-screen" style={{ background: 'var(--white)' }}>
      <header style={{ background: 'var(--dark-accent)' }} className="text-white">
        <div className="max-w-3xl mx-auto px-4 py-6 flex items-center justify-between">
          <Link href="/series" className="text-sm opacity-70 hover:opacity-100">
            ← Back to Quick Tips series
          </Link>
          <button
            onClick={() => toggle(episode.slug)}
            className="text-sm px-3 py-1.5 rounded-full transition"
            style={{
              background: isLearned(episode.slug) ? 'var(--accent)' : 'rgba(255,255,255,0.15)',
              color: isLearned(episode.slug) ? 'var(--black)' : 'var(--white)',
            }}
          >
            {isLearned(episode.slug) ? "✓ Learned" : "Mark as learned"}
          </button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-4">
          <span
            className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-white text-sm"
            style={{ background: 'var(--black)' }}
          >
            {episode.week}
          </span>
          <span className="text-sm opacity-60">Week {episode.week} of 10</span>
          {episode.released ? (
            <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'var(--accent)', color: 'var(--black)' }}>▶ Live</span>
          ) : (
            <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'var(--light-accent)' }}>
              Drops {episode.releaseDate}
            </span>
          )}
        </div>

        <h1 className="text-3xl mb-3">{episode.title}</h1>
        <p className="text-lg opacity-70 mb-2 italic" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>&ldquo;{episode.hook}&rdquo;</p>
        <p className="text-sm opacity-50 mb-8" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>Format: {episode.postFormat}</p>

        {/* Video or Placeholder */}
        {episode.released && episode.videoUrl ? (
          <section className="mb-8">
            <div className="relative w-full max-w-[360px] mx-auto aspect-[9/16] bg-black rounded-lg overflow-hidden">
              <iframe
                src={episode.videoUrl}
                className="absolute inset-0 w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                title={episode.title}
              />
            </div>
          </section>
        ) : (
          <section className="mb-8">
            <div className="relative w-full max-w-[360px] mx-auto aspect-[9/16] rounded-lg flex flex-col items-center justify-center text-center p-6" style={{ background: 'var(--light-accent)', border: '2px dashed var(--dark-accent)' }}>
              <span className="text-4xl mb-3">📅</span>
              <p className="font-medium">Coming {episode.releaseDate}</p>
              <p className="text-sm mt-1 opacity-60">This episode drops on Thursday. Check back or follow on LinkedIn to watch it first.</p>
            </div>
          </section>
        )}

        {/* Takeaways */}
        <section className="mb-8">
          <h2 className="text-xl mb-4">🎯 3 Actionable Takeaways</h2>
          <ol className="space-y-3">
            {episode.takeaways.map((takeaway, i) => (
              <li key={i} className="flex gap-3">
                <span
                  className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-sm font-medium text-white"
                  style={{ background: 'var(--black)' }}
                >
                  {i + 1}
                </span>
                <p className="pt-0.5" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>{takeaway}</p>
              </li>
            ))}
          </ol>
        </section>

        {/* LinkedIn CTA */}
        <section className="mb-8 rounded-lg p-5" style={{ background: 'var(--light-accent)' }}>
          <p className="font-medium mb-2" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>Watch on LinkedIn</p>
          <p className="text-sm opacity-70 mb-3" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>
            {episode.released
              ? "This episode is live! Watch, like, and share to help other creators find it."
              : "This episode hasn't dropped yet. Follow Divina to get notified when it goes live."}
          </p>
          <a
            href={episode.linkedInUrl || SERIES_INFO.linkedInProfile}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block text-white text-sm transition hover:opacity-90"
            style={{ background: 'var(--black)', padding: '1.2em 2em', borderRadius: '6.4px', fontFamily: 'Epilogue, sans-serif', textTransform: 'uppercase' }}
          >
            {episode.released ? "Watch Now →" : "Follow for Updates →"}
          </a>
        </section>

        {/* Series tagline */}
        <div className="text-center py-6" style={{ borderTop: '1px solid var(--light-accent)' }}>
          <p className="text-sm italic opacity-60" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>{SERIES_INFO.tagline}</p>
        </div>

        {/* Navigation */}
        <div className="flex justify-between pt-4" style={{ borderTop: '1px solid var(--light-accent)' }}>
          {prevEp ? (
            <Link href={`/series/${prevEp.slug}`} className="text-sm hover:opacity-70" style={{ color: 'var(--brand-purple)' }}>
              ← Week {prevEp.week}: {prevEp.title}
            </Link>
          ) : <span />}
          {nextEp ? (
            <Link href={`/series/${nextEp.slug}`} className="text-sm hover:opacity-70" style={{ color: 'var(--brand-purple)' }}>
              Week {nextEp.week}: {nextEp.title} →
            </Link>
          ) : <span />}
        </div>
      </main>
    </div>
  );
}

import Link from "next/link";
import { SERIES_INFO, episodes } from "@/lib/series";

export default function SeriesPage() {
  return (
    <div className="min-h-screen" style={{ background: 'var(--white)' }}>
      <header style={{ background: 'var(--dark-accent)' }} className="text-white">
        <div className="max-w-4xl mx-auto px-4 py-10">
          <Link href="/" className="text-sm opacity-70 hover:opacity-100">
            ← Back to all tips
          </Link>
          <h1 className="text-3xl md:text-4xl mt-4">🎬 {SERIES_INFO.title}</h1>
          <p className="text-lg mt-2 italic opacity-90" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>{SERIES_INFO.tagline}</p>
          <p className="mt-4 opacity-80" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>{SERIES_INFO.hook}</p>
          <div className="flex items-center gap-4 mt-6 text-sm" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>
            <span className="bg-white/10 px-3 py-1 rounded-full">📅 {SERIES_INFO.cadence}</span>
            <a
              href={SERIES_INFO.linkedInProfile}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1 rounded-full transition hover:opacity-90"
              style={{ background: 'var(--black)', color: 'var(--white)' }}
            >
              Follow on LinkedIn →
            </a>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <h2 className="text-2xl mb-6">10-Week Content Calendar</h2>
        <div className="space-y-4">
          {episodes.map((ep) => (
            <Link
              key={ep.slug}
              href={`/series/${ep.slug}`}
              className="block rounded-lg p-5 transition hover:shadow-md"
              style={{
                border: `1px solid ${ep.released ? 'var(--accent)' : 'var(--light-accent)'}`,
                background: ep.released ? 'var(--light-accent)' : 'var(--white)',
              }}
            >
              <div className="flex items-start gap-4">
                <div
                  className="flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center font-bold text-white"
                  style={{ background: 'var(--black)' }}
                >
                  {ep.week}
                </div>
                <div className="flex-grow">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-lg" style={{ fontFamily: 'Epilogue, sans-serif', fontWeight: 600, textTransform: 'none' }}>{ep.title}</h3>
                    {ep.released && (
                      <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'var(--accent)', color: 'var(--black)' }}>
                        ▶ Live
                      </span>
                    )}
                    {!ep.released && (
                      <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'var(--light-accent)' }}>
                        Coming {ep.releaseDate}
                      </span>
                    )}
                  </div>
                  <p className="text-sm mt-1 opacity-70">{ep.hook}</p>
                  <span className="text-xs opacity-50 mt-2 inline-block">{ep.postFormat}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}

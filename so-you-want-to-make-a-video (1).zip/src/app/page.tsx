"use client";

import { useState, useMemo } from "react";
import { Category, SkillLevel, CATEGORIES, LEVELS } from "@/lib/types";
import { tips } from "@/lib/tips";
import { useProgress } from "@/lib/useProgress";
import { TipCard } from "@/components/TipCard";
import { FilterBar } from "@/components/FilterBar";

export default function Home() {
  const [category, setCategory] = useState<Category | null>(null);
  const [level, setLevel] = useState<SkillLevel | null>(null);
  const [search, setSearch] = useState("");
  const { toggle, isLearned, count } = useProgress();

  const filtered = useMemo(() => {
    return tips.filter((t) => {
      if (category && t.category !== category) return false;
      if (level && t.level !== level) return false;
      if (search) {
        const q = search.toLowerCase();
        return (
          t.title.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q) ||
          t.tags.some((tag) => tag.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [category, level, search]);

  const grouped = useMemo(() => {
    if (level && !category) {
      const groups: { key: string; label: string; icon: string; tips: typeof filtered }[] = [];
      const catOrder = Object.keys(CATEGORIES) as Category[];
      for (const cat of catOrder) {
        const catTips = filtered.filter((t) => t.category === cat);
        if (catTips.length > 0) groups.push({ key: `category-${cat}`, label: CATEGORIES[cat].label, icon: CATEGORIES[cat].icon, tips: catTips });
      }
      return groups;
    }
    if (category && !level) {
      const groups: { key: string; label: string; icon: string; tips: typeof filtered }[] = [];
      const lvlOrder = Object.keys(LEVELS) as SkillLevel[];
      for (const lvl of lvlOrder) {
        const lvlTips = filtered.filter((t) => t.level === lvl);
        if (lvlTips.length > 0) groups.push({ key: `level-${lvl}`, label: LEVELS[lvl].label, icon: lvl === "beginner" ? "🌱" : lvl === "intermediate" ? "🌿" : "🌳", tips: lvlTips });
      }
      return groups;
    }
    const groups: { key: string; label: string; icon: string; tips: typeof filtered }[] = [];
    const catOrder = Object.keys(CATEGORIES) as Category[];
    for (const cat of catOrder) {
      const catTips = filtered.filter((t) => t.category === cat);
      if (catTips.length > 0) groups.push({ key: `category-${cat}`, label: CATEGORIES[cat].label, icon: CATEGORIES[cat].icon, tips: catTips });
    }
    return groups;
  }, [filtered, category, level]);

  return (
    <div className="min-h-screen" style={{ background: 'var(--white)' }}>
      {/* Hero Header */}
      <header style={{ background: 'var(--black)' }} className="text-white">
        <div className="max-w-6xl mx-auto px-4 py-12">
          <h1 className="text-4xl md:text-5xl">🎬 So You Want to Make a Video</h1>
          <p className="mt-3 text-lg" style={{ color: 'var(--light-accent)', fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>
            Practical tips and instructions for communication professionals creating video content.
          </p>
          <div className="mt-4 flex items-center gap-4 text-sm" style={{ color: 'var(--dark-accent)', fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>
            <span>{tips.length} tips available</span>
            <span>•</span>
            <span style={{ color: 'var(--accent)' }}>{count} learned</span>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Site Intro */}
        <section className="mb-12 max-w-3xl mx-auto text-center">
          <p className="text-2xl font-semibold mb-6" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none', lineHeight: '1.4' }}>
            You don&apos;t need a $5K camera. You don&apos;t need a ring light. You don&apos;t need permission to start.
          </p>
          <div className="space-y-4 opacity-80" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none', lineHeight: '1.7' }}>
            <p>
              After 20+ years in broadcast news, breaking stories, and brand communications, I&apos;ve learned one thing over and over again: <strong>gear doesn&apos;t make the story. You do.</strong>
            </p>
            <p>
              This series is everything I wish someone had handed me on day one — the real-world skills that turn your phone into a production studio and your ideas into scroll-stopping content. Whether you&apos;re a communications pro looking to level up, a team lead who wants to capture your next event, or someone who&apos;s been saying &ldquo;I&apos;ll start when I&apos;m ready&rdquo; for way too long — <strong>this is your starting line.</strong>
            </p>
            <p>
              New episodes drop weekly. Each one is built so you can learn at your own pace, practice with the tools you already own, and start creating content that actually connects.
            </p>
          </div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
            <div>
              <h2 className="text-xl mb-3">What You&apos;ll Learn</h2>
              <ul className="space-y-2 opacity-80" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none', lineHeight: '1.6' }}>
                <li>📱 How to shoot compelling A-roll and cinematic B-roll — with your phone</li>
                <li>💡 Where creative ideas actually come from (and how to find them faster)</li>
                <li>🎙️ How to capture sound bites that make the story</li>
                <li>✂️ Editing shortcuts that cut your production time in half</li>
                <li>📲 The cell phone apps I actually use in the field</li>
                <li>✍️ How to write news copy that hooks in 5 seconds</li>
                <li>📰 How to pitch local media — from someone who&apos;s been on both sides</li>
              </ul>
            </div>
            <div>
              <h2 className="text-xl mb-3">Who This Is For</h2>
              <p className="opacity-80" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none', lineHeight: '1.7' }}>
                Anyone who wants to tell better stories through video. No experience required. No fancy equipment needed. Just you, your phone, and the willingness to hit record.
              </p>
              <p className="mt-6 text-lg font-semibold" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none', color: 'var(--brand-purple)' }}>
                Ready? Let&apos;s go. ↓
              </p>
            </div>
          </div>
        </section>

        {/* Series Banner */}
        <a href="/series" className="block mb-8 text-white rounded-lg p-6 hover:opacity-95 transition" style={{ backgroundColor: 'var(--dark-accent)' }}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm opacity-80" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>📺 Video Series</p>
              <h2 className="text-2xl mt-1">Quick Tips</h2>
              <p className="text-sm mt-1 opacity-80 italic" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>Real skills. Real results. No excuses.</p>
            </div>
            <span className="text-3xl opacity-60">→</span>
          </div>
        </a>

        <FilterBar
          selectedCategory={category}
          selectedLevel={level}
          searchQuery={search}
          onCategoryChange={setCategory}
          onLevelChange={setLevel}
          onSearchChange={setSearch}
        />

        <p className="text-sm mb-4" style={{ color: 'var(--dark-accent)', fontFamily: 'Epilogue, sans-serif' }}>
          Showing {filtered.length} tip{filtered.length !== 1 ? "s" : ""}
        </p>

        <div id="tips-grid" className="space-y-10 scroll-mt-4">
          {grouped.map(({ key, label, icon, tips: groupTips }) => (
            <section key={key} id={key} className="scroll-mt-4">
              <h2 className="text-2xl mb-4 flex items-center gap-2">
                <span>{icon}</span>
                {label}
                <span className="text-sm font-normal opacity-50" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>({groupTips.length})</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {groupTips.map((tip) => (
                  <TipCard
                    key={tip.slug}
                    tip={tip}
                    isLearned={isLearned(tip.slug)}
                    onToggleLearn={toggle}
                  />
                ))}
              </div>
            </section>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12 opacity-60">
            No tips match your filters. Try a different combination.
          </div>
        )}

        {/* About Section */}
        <section className="mt-16 border-t pt-10" style={{ borderColor: 'var(--light-accent)' }}>
          <div className="rounded-lg p-8 text-center" style={{ background: 'var(--light-accent)' }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="https://images.squarespace-cdn.com/content/v1/69906c5b7989eb6787167e4b/f6f77598-9317-4cd0-b047-7f8f124ad961/IMG_5317.jpeg?format=500w"
              alt="Divina Mims"
              className="w-28 h-28 rounded-full object-cover mx-auto mb-4 border-4 shadow-md"
              style={{ borderColor: 'var(--white)' }}
            />
            <h2 className="text-2xl mb-3">About Divina Mims</h2>
            <p className="max-w-2xl mx-auto mb-6" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none', color: 'var(--black)' }}>
              Emmy-nominated journalist, video strategist, and communications leader. From breaking news control rooms to corporate boardrooms — helping professionals tell stories that matter.
            </p>
            <a
              href="https://www.divinamimsmedia.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block text-white font-medium rounded transition hover:opacity-90"
              style={{ backgroundColor: 'var(--black)', padding: '1.2em 2em', fontFamily: 'Epilogue, sans-serif', textTransform: 'uppercase', fontSize: '1rem', borderRadius: '6.4px' }}
            >
              Visit DivinaMimsMedia.com →
            </a>
          </div>
        </section>
      </main>
    </div>
  );
}

"use client";

import { useRef } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { getTipBySlug } from "@/lib/tips";
import { CATEGORIES, LEVELS } from "@/lib/types";
import { useProgress } from "@/lib/useProgress";

export default function TipPage() {
  const { slug } = useParams<{ slug: string }>();
  const tip = getTipBySlug(slug);
  const { toggle, isLearned } = useProgress();
  const checklistRef = useRef<HTMLDivElement>(null);

  if (!tip) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Tip not found.</p>
      </div>
    );
  }

  const category = CATEGORIES[tip.category];
  const level = LEVELS[tip.level];

  const handlePrint = () => {
    const win = window.open("", "_blank");
    if (!win) return;
    win.document.write(`
      <html><head><title>${tip.title} - Checklist</title>
      <style>
        body { font-family: "Epilogue", system-ui, sans-serif; padding: 2rem; max-width: 600px; color: #161C39; }
        h1 { font-family: "Anton", sans-serif; font-size: 1.5rem; text-transform: uppercase; margin-bottom: 0.5rem; }
        h2 { font-size: 1rem; color: #93AAF8; margin-bottom: 1.5rem; font-family: "Epilogue", sans-serif; }
        ul { list-style: none; padding: 0; }
        li { padding: 0.5rem 0; border-bottom: 1px solid #E5E9FC; }
        li::before { content: "☐ "; }
        .equipment { margin-top: 1.5rem; }
        .equipment li::before { content: "• "; }
        @media print { body { padding: 0; } }
      </style></head><body>
      <h1>${tip.title}</h1>
      <h2>${category.label} · ${level.label} · ${tip.phase.replace("-", " ")}</h2>
      ${tip.checklist ? `<ul>${tip.checklist.map((i) => `<li>${i}</li>`).join("")}</ul>` : ""}
      ${tip.equipment ? `<div class="equipment"><strong>Equipment:</strong><ul>${tip.equipment.map((i) => `<li>${i}</li>`).join("")}</ul></div>` : ""}
      </body></html>
    `);
    win.document.close();
    win.print();
  };

  return (
    <div className="min-h-screen" style={{ background: 'var(--white)' }}>
      <header style={{ background: 'var(--black)' }} className="text-white">
        <div className="max-w-3xl mx-auto px-4 py-6 flex items-center justify-between">
          <Link href="/" className="text-sm opacity-70 hover:opacity-100">
            ← Back to all tips
          </Link>
          <button
            onClick={() => toggle(tip.slug)}
            className="text-sm px-3 py-1.5 rounded-full transition"
            style={{
              background: isLearned(tip.slug) ? 'var(--accent)' : 'rgba(255,255,255,0.15)',
              color: isLearned(tip.slug) ? 'var(--black)' : 'var(--white)',
            }}
          >
            {isLearned(tip.slug) ? "✓ Learned" : "Mark as learned"}
          </button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-4 flex-wrap">
          <span className="text-2xl">{category.icon}</span>
          <span className="text-sm opacity-60">{category.label}</span>
          <span
            className="text-xs px-2 py-0.5 rounded-full"
            style={{ background: 'var(--light-accent)' }}
          >
            {level.label}
          </span>
          <span
            className="text-xs px-2 py-0.5 rounded-full capitalize"
            style={{ background: 'var(--light-accent)' }}
          >
            {tip.phase.replace("-", " ")}
          </span>
        </div>

        <h1 className="text-3xl mb-4">{tip.title}</h1>
        <p className="text-lg opacity-70 mb-8" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>{tip.description}</p>

        {/* Video Embed */}
        {tip.videoUrl && (
          <section className="mb-8">
            <h2 className="text-xl mb-3">🎥 Video Example</h2>
            <div className="relative w-full pb-[56.25%] rounded-lg overflow-hidden" style={{ background: 'var(--black)' }}>
              <iframe
                src={tip.videoUrl}
                className="absolute inset-0 w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                title={`Video: ${tip.title}`}
              />
            </div>
          </section>
        )}

        {/* Diagram */}
        {tip.diagramUrl && (
          <section className="mb-8">
            <h2 className="text-xl mb-3">📐 Setup Diagram</h2>
            <div className="rounded-lg p-4 flex items-center justify-center min-h-[200px]" style={{ background: 'var(--light-accent)' }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={tip.diagramUrl}
                alt={tip.diagramAlt || `Diagram for ${tip.title}`}
                className="max-w-full h-auto"
              />
            </div>
            {tip.diagramAlt && (
              <p className="text-sm mt-2 italic opacity-60">{tip.diagramAlt}</p>
            )}
          </section>
        )}

        {/* Step-by-Step Instructions */}
        {tip.steps && (
          <section className="mb-8">
            <h2 className="text-xl mb-3">📝 Step-by-Step</h2>
            <ol className="space-y-4">
              {tip.steps.map((step, i) => (
                <li key={i} className="flex gap-3">
                  <span
                    className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-sm font-medium text-white"
                    style={{ background: 'var(--brand-purple)' }}
                  >
                    {i + 1}
                  </span>
                  <div>
                    <h3 className="font-medium" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>{step.title}</h3>
                    <p className="text-sm mt-0.5 opacity-70">{step.description}</p>
                  </div>
                </li>
              ))}
            </ol>
          </section>
        )}

        {/* Checklist */}
        {tip.checklist && (
          <section className="mb-8" ref={checklistRef}>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xl">✅ Checklist</h2>
              <button
                onClick={handlePrint}
                className="text-sm flex items-center gap-1 hover:opacity-70 transition"
                style={{ color: 'var(--brand-purple)', fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}
              >
                🖨️ Print / Export
              </button>
            </div>
            <ul className="space-y-2">
              {tip.checklist.map((item, i) => (
                <li key={i} className="flex items-start gap-2 py-1" style={{ borderBottom: '1px solid var(--light-accent)' }}>
                  <span style={{ color: 'var(--accent)' }}>☐</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </section>
        )}

        {/* Equipment */}
        {tip.equipment && (
          <section className="mb-8">
            <h2 className="text-xl mb-3">🎒 Equipment</h2>
            <ul className="space-y-1">
              {tip.equipment.map((item, i) => (
                <li key={i} className="opacity-80">• {item}</li>
              ))}
            </ul>
          </section>
        )}

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mt-8 pt-4" style={{ borderTop: '1px solid var(--light-accent)' }}>
          {tip.tags.map((tag) => (
            <span key={tag} className="text-sm px-3 py-1 rounded-full" style={{ background: 'var(--light-accent)' }}>
              #{tag}
            </span>
          ))}
        </div>
      </main>
    </div>
  );
}

export type SkillLevel = "beginner" | "intermediate" | "advanced";

export type Category =
  | "a-roll"
  | "b-roll"
  | "voiceover"
  | "interview"
  | "social-media"
  | "event-summary"
  | "broadcast";

export type ProductionPhase = "pre-production" | "production" | "post-production";

export interface Step {
  title: string;
  description: string;
  image?: string;
}

export interface Tip {
  slug: string;
  title: string;
  description: string;
  category: Category;
  level: SkillLevel;
  phase: ProductionPhase;
  tags: string[];
  checklist?: string[];
  equipment?: string[];
  videoUrl?: string;
  diagramUrl?: string;
  diagramAlt?: string;
  steps?: Step[];
}

export const CATEGORIES: Record<Category, { label: string; icon: string }> = {
  "a-roll": { label: "A-Roll", icon: "🎬" },
  "b-roll": { label: "B-Roll", icon: "🎥" },
  voiceover: { label: "Voiceover", icon: "🎙️" },
  interview: { label: "Interviews", icon: "🗣️" },
  "social-media": { label: "Social Media", icon: "📱" },
  "event-summary": { label: "Event Summaries", icon: "📋" },
  broadcast: { label: "Broadcast", icon: "📡" },
};

export const LEVELS: Record<SkillLevel, { label: string; color: string }> = {
  beginner: { label: "Beginner", color: "bg-green-100 text-green-800" },
  intermediate: { label: "Intermediate", color: "bg-yellow-100 text-yellow-800" },
  advanced: { label: "Advanced", color: "bg-red-100 text-red-800" },
};

export interface Episode {
  week: number;
  slug: string;
  title: string;
  hook: string;
  postFormat: string;
  takeaways: string[];
  released: boolean;
  releaseDate?: string;
  videoUrl?: string;
  linkedInUrl?: string;
}

export const SERIES_INFO = {
  title: "Quick Tips",
  tagline: "Real skills. Real results. No excuses.",
  hook: "You don't need a crew. You don't need a studio. You need what you already have — and someone who's done it from breaking news control rooms to Amazon boardrooms to tell you how.",
  cadence: "New episode every Thursday",
  format: "60–90 sec vertical video + carousel or text post recap + 3 actionable takeaways",
  linkedInProfile: "https://www.linkedin.com/in/divinamims/",
};

export const episodes: Episode[] = [
  {
    week: 1,
    slug: "what-you-need",
    title: "What You Need (Spoiler: You Already Have Enough)",
    hook: "Stop waiting on gear. Your phone is a broadcast studio.",
    postFormat: "Video + caption",
    takeaways: [
      "Your smartphone camera is more powerful than the cameras used to shoot award-winning news stories 10 years ago",
      "Start with what you have — a phone, natural light, and a quiet room is all you need for episode one",
      "The best gear is the gear you'll actually use consistently",
    ],
    released: true,
    releaseDate: "2025-05-29",
    videoUrl: "https://www.youtube.com/embed/PwMNwNNAc-E",
  },
  {
    week: 2,
    slug: "where-do-creative-ideas-come-from",
    title: "Where Do Creative Ideas Come From?",
    hook: "The idea isn't hiding — you're just not looking in the right places.",
    postFormat: "Video + carousel",
    takeaways: [
      "Keep a running 'idea bank' in your notes app — capture everything, curate later",
      "Steal the structure, not the content: study formats that work and adapt them to your story",
      "Your daily work IS content — document the process, not just the polished result",
    ],
    released: false,
    releaseDate: "2025-06-05",
  },
  {
    week: 3,
    slug: "capturing-content-faster",
    title: "Capturing Content: Getting Better & Faster",
    hook: "Speed is a skill. Here's how pros train it.",
    postFormat: "Video + tips list",
    takeaways: [
      "Batch your content: shoot 3-4 videos in one session to build momentum",
      "Use a shot list template so you never waste time deciding what to film next",
      "Set a timer — constraints force creativity and eliminate perfectionism",
    ],
    released: false,
    releaseDate: "2025-06-12",
  },
  {
    week: 4,
    slug: "basics-of-a-roll",
    title: "Basics of A-Roll",
    hook: "You ARE the story. How to be compelling on camera.",
    postFormat: "Video + before/after",
    takeaways: [
      "Look at the lens, not the screen — eye contact builds trust even through a phone",
      "Speak to ONE person, not an audience. Conversation beats presentation every time",
      "Energy on camera needs to be 20% more than real life — what feels 'too much' looks natural on screen",
    ],
    released: false,
    releaseDate: "2025-06-19",
  },
  {
    week: 5,
    slug: "basics-of-b-roll",
    title: "Basics of B-Roll",
    hook: "The secret weapon that makes average videos look professional.",
    postFormat: "Video + examples",
    takeaways: [
      "B-roll covers your cuts — shoot 10 seconds of everything around your story",
      "Get three angles of every scene: wide, medium, close-up",
      "Movement sells: pans, tilts, and tracking shots add production value with zero budget",
    ],
    released: false,
    releaseDate: "2025-06-26",
  },
  {
    week: 6,
    slug: "how-to-capture-sots",
    title: "How to Capture SOTs (Sound on Tape)",
    hook: "The quote that makes the story — how to get it every time.",
    postFormat: "Video + carousel",
    takeaways: [
      "Ask open-ended questions and then stay silent — the best bites come after the pause",
      "Get your subject to include the question in their answer for self-contained soundbites",
      "Record 30 seconds of room tone for clean audio editing later",
    ],
    released: false,
    releaseDate: "2025-07-03",
  },
  {
    week: 7,
    slug: "editing-shortcuts",
    title: "Editing Shortcuts",
    hook: "Cut your editing time in half with these non-negotiables.",
    postFormat: "Video + quick-tips carousel",
    takeaways: [
      "Learn 5 keyboard shortcuts in your editor — they compound into hours saved per week",
      "Edit to the audio first, then lay visuals on top. Story structure before pretty pictures",
      "Use templates and presets for colors, titles, and transitions — don't reinvent every time",
    ],
    released: false,
    releaseDate: "2025-07-10",
  },
  {
    week: 8,
    slug: "favorite-phone-editing-apps",
    title: "My Favorite Cell Phone Editing Apps",
    hook: "Tested in the field. Divina-approved.",
    postFormat: "Video + ranked list",
    takeaways: [
      "CapCut for quick social edits — free, powerful, and intuitive",
      "InShot for stories and reels when you need speed over precision",
      "LumaFusion (iOS) or KineMaster for when you need desktop-level control on mobile",
    ],
    released: false,
    releaseDate: "2025-07-17",
  },
  {
    week: 9,
    slug: "writing-news-copy-script",
    title: "Writing a News Copy Script",
    hook: "The structure that hooks in 5 seconds — every time.",
    postFormat: "Video + script template",
    takeaways: [
      "Lead with the 'so what' — tell viewers why they should care in the first line",
      "Write for the ear: short sentences, active voice, present tense",
      "End with a forward look or call to action — never let the energy just... stop",
    ],
    released: false,
    releaseDate: "2025-07-24",
  },
  {
    week: 10,
    slug: "pitching-local-media",
    title: "Pitching Local Media: Tips That Actually Work",
    hook: "I've been on both sides of the pitch. Here's what lands.",
    postFormat: "Video + DM-able checklist",
    takeaways: [
      "Lead with the local angle — why does THIS community care about YOUR story?",
      "Keep your pitch to 3 sentences max. If you can't say it fast, they won't read it",
      "Offer assets: b-roll, a spokesperson, a location. Make their job easier and you'll get covered",
    ],
    released: false,
    releaseDate: "2025-07-31",
  },
];

export function getEpisodeBySlug(slug: string): Episode | undefined {
  return episodes.find((e) => e.slug === slug);
}

"use client";

import { useState, useEffect, useCallback } from "react";

const STORAGE_KEY = "video-tips-progress";

export function useProgress() {
  const [learned, setLearned] = useState<string[]>([]);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) setLearned(JSON.parse(stored));
    } catch {}
  }, []);

  const toggle = useCallback((slug: string) => {
    setLearned((prev) => {
      const next = prev.includes(slug) ? prev.filter((s) => s !== slug) : [...prev, slug];
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch {}
      return next;
    });
  }, []);

  const isLearned = useCallback((slug: string) => learned.includes(slug), [learned]);
  const count = learned.length;

  return { toggle, isLearned, count, mounted };
}

import { Tip, Category, SkillLevel } from "./types";

export const tips: Tip[] = [
  // === B-ROLL ===
  {
    slug: "what-is-b-roll",
    title: "What is B-Roll and Why You Need It",
    description:
      "B-roll is supplemental footage that adds visual interest and context to your primary footage. Learn the 5 essential B-roll shots every video needs.",
    category: "b-roll",
    level: "beginner",
    phase: "production",
    tags: ["fundamentals", "shooting"],
    videoUrl: "https://www.youtube.com/embed/F3uYh2fAHsY",
    checklist: [
      "Identify your story's key themes",
      "Shoot wide, medium, and close-up versions",
      "Get at least 10 seconds per shot",
      "Capture natural movement",
      "Shoot more than you think you need",
    ],
    equipment: ["Any camera or smartphone", "Tripod (optional)"],
    steps: [
      { title: "Identify the story", description: "Before shooting, list 5 visual themes that support your narrative." },
      { title: "Plan your shot sizes", description: "For each theme, plan a wide, medium, and close-up shot." },
      { title: "Shoot with overlap", description: "Hold each shot for 10+ seconds. Start recording before action begins." },
      { title: "Capture movement", description: "Look for natural motion — hands working, traffic, wind in trees." },
      { title: "Review on location", description: "Check footage before leaving to ensure you have enough coverage." },
    ],
  },
  {
    slug: "b-roll-shot-list-planning",
    title: "Creating a B-Roll Shot List",
    description:
      "Plan your B-roll before you arrive on location. A shot list saves time and ensures you don't miss critical coverage.",
    category: "b-roll",
    level: "beginner",
    phase: "pre-production",
    tags: ["planning", "shot-list", "organization"],
    checklist: [
      "Review the script or story outline",
      "List every visual reference mentioned",
      "Add establishing shots for each location",
      "Include detail/texture shots",
      "Note time-sensitive shots (golden hour, events)",
      "Prioritize must-have vs nice-to-have",
    ],
    steps: [
      { title: "Read the script twice", description: "First for story, second specifically noting every visual element mentioned or implied." },
      { title: "Categorize by location", description: "Group shots by where they'll be captured to minimize travel between setups." },
      { title: "Assign priority levels", description: "Mark each shot as essential, important, or bonus. Shoot in that order." },
    ],
  },
  {
    slug: "cinematic-b-roll-techniques",
    title: "Cinematic B-Roll: Movement and Composition",
    description:
      "Elevate your B-roll with parallax, rack focus, and motivated camera movement. Techniques used in documentary and brand films.",
    category: "b-roll",
    level: "advanced",
    phase: "production",
    tags: ["cinematic", "movement", "composition"],
    videoUrl: "https://www.youtube.com/embed/nMqxNPsfN50",
    diagramUrl: "/diagrams/parallax-movement.svg",
    diagramAlt: "Diagram showing parallax camera movement with foreground and background layers",
    checklist: [
      "Plan movements that reveal information",
      "Use slider or gimbal for smooth motion",
      "Incorporate foreground elements for depth",
      "Match movement speed to mood",
      "Shoot at 60fps+ for slow-motion options",
    ],
    equipment: ["Cinema camera or mirrorless", "Gimbal/slider", "ND filters", "Monitor"],
    steps: [
      { title: "Set your foreground", description: "Place an object 1-3 feet from the lens to create depth layers as you move." },
      { title: "Motivate the movement", description: "Every camera move should reveal new information or follow a subject's action." },
      { title: "Control your speed", description: "Slower = more cinematic. Match movement speed to the emotional tone of the scene." },
      { title: "Rack focus for emphasis", description: "Shift focus between foreground and background to direct viewer attention." },
    ],
  },
  {
    slug: "b-roll-matching-narrative",
    title: "Shooting B-Roll That Matches Your Narrative",
    description:
      "Learn to shoot B-roll that directly supports and enhances your story rather than generic filler footage.",
    category: "b-roll",
    level: "intermediate",
    phase: "production",
    tags: ["storytelling", "narrative", "editing"],
    checklist: [
      "Identify emotional beats in your script",
      "Shoot metaphorical imagery for abstract concepts",
      "Match shot energy to narration pacing",
      "Get reaction shots and environmental context",
      "Shoot transitions (doors opening, walking, turning corners)",
    ],
    steps: [
      { title: "Map script to visuals", description: "Go line by line through narration and assign a visual to each sentence." },
      { title: "Think in sequences", description: "Shoot 3-5 related shots that can be cut together as a mini-sequence." },
      { title: "Capture emotion", description: "Faces, hands, body language — these connect viewers to the story." },
    ],
  },

  // === A-ROLL ===
  {
    slug: "a-roll-fundamentals",
    title: "A-Roll Basics: Your Primary Footage",
    description:
      "A-roll is your main footage — the interviews, presentations, and on-camera talent that drive your story forward.",
    category: "a-roll",
    level: "beginner",
    phase: "production",
    tags: ["fundamentals", "primary-footage", "framing"],
    videoUrl: "https://www.youtube.com/embed/dcYBL2vOZMI",
    checklist: [
      "Frame subject using rule of thirds",
      "Ensure clean audio is priority #1",
      "Check background for distractions",
      "Maintain consistent eye-line",
      "Record 10 seconds before and after action",
    ],
    equipment: ["Camera with manual controls", "External microphone", "Tripod", "LED light panel"],
    steps: [
      { title: "Set your frame", description: "Place subject's eyes on the upper third line. Leave 'look room' in the direction they face." },
      { title: "Lock audio first", description: "Get clean audio before worrying about the perfect shot. Bad audio ruins good video." },
      { title: "Check the background", description: "Look for poles 'growing' from heads, moving distractions, or brand logos you can't use." },
      { title: "Roll early, cut late", description: "Start recording 10 seconds before action and keep rolling 10 seconds after." },
    ],
  },
  {
    slug: "multicam-a-roll",
    title: "Multi-Camera A-Roll Setup",
    description:
      "Use two or more cameras to give yourself editing flexibility and visual variety in interviews and presentations.",
    category: "a-roll",
    level: "intermediate",
    phase: "production",
    tags: ["multicam", "setup", "editing-flexibility"],
    diagramUrl: "/diagrams/multicam-setup.svg",
    diagramAlt: "Overhead diagram showing two-camera interview setup with 30-degree angle offset",
    checklist: [
      "Match white balance across all cameras",
      "Sync timecode or use a clap/slate",
      "Vary focal lengths between cameras (wide + tight)",
      "Offset cameras by 30-45 degrees",
      "Monitor both feeds simultaneously if possible",
    ],
    equipment: ["2+ cameras", "Matching lenses or zoom lenses", "Audio recorder with timecode", "Monitor/switcher"],
    steps: [
      { title: "Position camera A", description: "Place your primary camera at subject eye level, slightly off-center for a natural look." },
      { title: "Position camera B", description: "Set 30-45° offset from camera A. Use a tighter focal length for variety." },
      { title: "Match settings", description: "Sync white balance, frame rate, and exposure across both cameras." },
      { title: "Create a sync point", description: "Clap hands or use a slate at the start of each take for easy sync in post." },
    ],
  },
  {
    slug: "a-roll-directing-non-actors",
    title: "Directing Non-Actors on Camera",
    description:
      "Most corporate and communications video features real people, not actors. Learn techniques to help them feel natural and deliver authentic performances.",
    category: "a-roll",
    level: "advanced",
    phase: "production",
    tags: ["directing", "talent", "authenticity"],
    checklist: [
      "Have a casual conversation before rolling",
      "Ask them to paraphrase rather than memorize",
      "Use prompter only as a safety net, not a script",
      "Give specific physical direction (hands, posture)",
      "Shoot multiple takes with different energy levels",
      "Tell them when NOT to look at camera",
    ],
    steps: [
      { title: "Build rapport first", description: "Chat for 5-10 minutes about anything unrelated. Let them forget the camera exists." },
      { title: "Explain the 'why'", description: "Tell them why their story matters. Purpose creates authentic energy." },
      { title: "Use conversational prompts", description: "Instead of 'read this,' ask 'tell me about...' and let them respond naturally." },
      { title: "Direct energy, not words", description: "Say 'try that again with more excitement' rather than changing their script." },
    ],
  },

  // === INTERVIEWS ===
  {
    slug: "interview-lighting-basics",
    title: "Three-Point Lighting for Interviews",
    description:
      "Set up professional interview lighting with just three lights. Key light, fill light, and backlight explained simply.",
    category: "interview",
    level: "beginner",
    phase: "production",
    tags: ["lighting", "setup", "interviews"],
    videoUrl: "https://www.youtube.com/embed/j_Sov3xmgwg",
    diagramUrl: "/diagrams/three-point-lighting.svg",
    diagramAlt: "Overhead diagram showing three-point lighting setup with key, fill, and back light positions",
    checklist: [
      "Position key light 45° to subject",
      "Set fill light opposite at lower intensity",
      "Add backlight to separate subject from background",
      "Check for unwanted shadows",
      "White balance your camera",
    ],
    equipment: ["2-3 LED panels or softboxes", "Light stands", "Diffusion material"],
    steps: [
      { title: "Place the key light", description: "Position your brightest light 45° to one side of the subject, slightly above eye level." },
      { title: "Add fill light", description: "Place a softer light on the opposite side at 50-70% of key light intensity to reduce shadows." },
      { title: "Set the backlight", description: "Position behind and above the subject to create a rim of light separating them from the background." },
      { title: "Fine-tune", description: "Check the monitor for hot spots, harsh shadows, or light spilling onto the background." },
    ],
  },
  {
    slug: "interview-questions-technique",
    title: "Asking Better Interview Questions",
    description:
      "The quality of your interview depends on your questions. Learn to ask open-ended questions that produce usable soundbites.",
    category: "interview",
    level: "beginner",
    phase: "pre-production",
    tags: ["questions", "preparation", "soundbites"],
    checklist: [
      "Start with easy warm-up questions",
      "Use open-ended questions (how, why, tell me about)",
      "Ask them to include the question in their answer",
      "Follow up with 'can you give me an example?'",
      "Save emotional/difficult questions for last",
      "Always ask 'is there anything else you'd like to add?'",
    ],
    steps: [
      { title: "Research your subject", description: "Know their background so you can ask specific, informed questions." },
      { title: "Write questions in order", description: "Start easy, build to the core story, end with reflection." },
      { title: "Prepare follow-ups", description: "For each question, have 2-3 follow-ups ready to dig deeper." },
      { title: "Practice the 'echo' technique", description: "Repeat their last few words as a question to get them to elaborate." },
    ],
  },
  {
    slug: "interview-audio-setup",
    title: "Interview Audio: Lav vs. Boom vs. Both",
    description:
      "Compare microphone options for interviews and learn when to use lavalier mics, boom mics, or a dual-mic setup.",
    category: "interview",
    level: "intermediate",
    phase: "production",
    tags: ["audio", "microphones", "setup"],
    diagramUrl: "/diagrams/mic-placement.svg",
    diagramAlt: "Diagram showing lavalier placement on clothing and boom mic positioning overhead",
    checklist: [
      "Test audio in the actual location before the interview",
      "Place lav mic 6-8 inches below chin",
      "Hide lav cable under clothing",
      "Position boom just outside frame, angled at mouth",
      "Record both sources to separate tracks",
      "Monitor with headphones throughout",
    ],
    equipment: ["Lavalier microphone", "Boom mic + pole", "Audio recorder or camera with XLR", "Headphones", "Gaffer tape for cable management"],
  },
  {
    slug: "interview-remote-recording",
    title: "Recording High-Quality Remote Interviews",
    description:
      "Get broadcast-quality audio and video from remote guests using double-ender techniques and the right software.",
    category: "interview",
    level: "advanced",
    phase: "production",
    tags: ["remote", "double-ender", "software"],
    checklist: [
      "Use a double-ender recording platform (Riverside, SquadCast)",
      "Send guest a checklist: quiet room, wired internet, eye-level camera",
      "Have guest record local audio as backup",
      "Test connection 15 minutes before",
      "Record a sync clap for alignment",
      "Use gallery view for natural eye contact",
    ],
    equipment: ["Double-ender platform subscription", "USB microphone for guest (ship if possible)", "Ring light for guest", "Wired internet connection"],
  },

  // === VOICEOVER ===
  {
    slug: "voiceover-recording-setup",
    title: "Home Voiceover Recording Setup",
    description:
      "Record broadcast-quality voiceovers at home with minimal equipment. Covers room treatment, mic technique, and recording settings.",
    category: "voiceover",
    level: "intermediate",
    phase: "post-production",
    tags: ["audio", "recording", "home-studio"],
    videoUrl: "https://www.youtube.com/embed/Ty8YLqOmbV4",
    diagramUrl: "/diagrams/vo-booth-setup.svg",
    diagramAlt: "Diagram showing home voiceover setup with mic position, acoustic treatment, and monitor placement",
    checklist: [
      "Choose a quiet, carpeted room",
      "Position mic 6-8 inches from mouth",
      "Use a pop filter",
      "Record at 48kHz/24-bit",
      "Leave 2 seconds of room tone at start",
      "Monitor with headphones while recording",
    ],
    equipment: [
      "USB condenser mic (e.g., Audio-Technica AT2020)",
      "Pop filter",
      "Headphones",
      "Acoustic panels or blankets",
    ],
    steps: [
      { title: "Treat the room", description: "Hang blankets or place acoustic panels at reflection points. A closet full of clothes works in a pinch." },
      { title: "Position the mic", description: "Place 6-8 inches from your mouth, slightly off-axis to reduce plosives." },
      { title: "Set levels", description: "Speak at your loudest and set gain so peaks hit -12dB. This leaves headroom." },
      { title: "Record room tone", description: "Capture 10 seconds of silence. This helps with noise reduction in post." },
      { title: "Do a test read", description: "Record 30 seconds, play back with headphones, and adjust before the full session." },
    ],
  },
  {
    slug: "voiceover-script-writing",
    title: "Writing Scripts for Voiceover",
    description:
      "Write scripts that sound natural when spoken aloud. Tips for pacing, readability, and timing your narration to visuals.",
    category: "voiceover",
    level: "beginner",
    phase: "pre-production",
    tags: ["writing", "scripting", "pacing"],
    checklist: [
      "Write for the ear, not the eye",
      "Use short sentences (15 words max)",
      "Read aloud while writing",
      "Time yourself: ~150 words per minute",
      "Mark pauses with '...' or [PAUSE]",
      "Bold words that need emphasis",
    ],
    steps: [
      { title: "Write conversationally", description: "Use contractions, simple words, and active voice. If you wouldn't say it to a friend, rewrite it." },
      { title: "Time to visuals", description: "At ~150 words/minute, a 60-second segment needs ~150 words. Leave breathing room." },
      { title: "Mark the script", description: "Use bold for emphasis, ellipses for pauses, and [SFX] or [MUSIC] cues for the editor." },
    ],
  },
  {
    slug: "voiceover-editing-cleanup",
    title: "Cleaning Up Voiceover in Post",
    description:
      "Remove breaths, mouth clicks, and room noise. EQ and compress for broadcast-ready narration.",
    category: "voiceover",
    level: "advanced",
    phase: "post-production",
    tags: ["editing", "audio-post", "mixing"],
    checklist: [
      "Apply noise reduction (use room tone as profile)",
      "Remove or reduce breaths between phrases",
      "De-click to remove mouth sounds",
      "Apply gentle compression (3:1 ratio, -18dB threshold)",
      "EQ: high-pass at 80Hz, slight boost at 3-5kHz for presence",
      "Normalize to -3dB peak, -16 LUFS integrated",
    ],
    equipment: ["DAW (Audacity, Adobe Audition, or Logic)", "iZotope RX (optional but powerful)", "Studio headphones"],
  },

  // === SOCIAL MEDIA ===
  {
    slug: "social-media-vertical-video",
    title: "Shooting Vertical Video That Works",
    description:
      "Tips for framing, pacing, and hooking viewers in the first 3 seconds for Instagram Reels, TikTok, and YouTube Shorts.",
    category: "social-media",
    level: "beginner",
    phase: "production",
    tags: ["vertical", "short-form", "hooks"],
    videoUrl: "https://www.youtube.com/embed/G5u2XjFfOdM",
    checklist: [
      "Frame subject in center-top third",
      "Leave space for text overlays (top and bottom 15%)",
      "Hook viewers in first 1-3 seconds",
      "Keep clips under 60 seconds",
      "Use native platform aspect ratios (9:16)",
    ],
    equipment: ["Smartphone", "Ring light or window light", "Phone tripod mount"],
    steps: [
      { title: "Plan your hook", description: "The first frame must stop the scroll. Start with action, a bold statement, or a visual surprise." },
      { title: "Frame for vertical", description: "Subject fills the center. Leave 15% margins top and bottom for platform UI and captions." },
      { title: "Keep it punchy", description: "Cut every 2-3 seconds. Remove all dead air. Viewers swipe in under 2 seconds if bored." },
    ],
  },
  {
    slug: "social-media-content-repurposing",
    title: "Repurposing Long-Form Video for Social",
    description:
      "Turn one long video into 10+ social media clips. Strategy for identifying shareable moments and reformatting.",
    category: "social-media",
    level: "intermediate",
    phase: "post-production",
    tags: ["repurposing", "strategy", "efficiency"],
    checklist: [
      "Watch full video and timestamp 'quotable moments'",
      "Identify self-contained 15-60 second segments",
      "Reframe horizontal to vertical (crop or reframe tool)",
      "Add captions — 85% of social video is watched muted",
      "Create platform-specific versions (different lengths/formats)",
      "Write scroll-stopping first line for caption",
    ],
    steps: [
      { title: "Timestamp while editing", description: "During your main edit, drop markers at every moment that could stand alone." },
      { title: "Extract and reframe", description: "Pull clips and use auto-reframe (Premiere) or manual crop for 9:16." },
      { title: "Add captions and graphics", description: "Burn in captions. Add a hook title in the first 2 seconds." },
      { title: "Customize per platform", description: "TikTok: trending audio. Reels: 30s max. LinkedIn: professional tone, square format." },
    ],
  },
  {
    slug: "social-media-platform-specs",
    title: "Video Specs for Every Platform (2024)",
    description:
      "Quick reference for resolution, aspect ratio, duration limits, and file size for all major social platforms.",
    category: "social-media",
    level: "beginner",
    phase: "post-production",
    tags: ["specs", "export", "platforms", "reference"],
    checklist: [
      "Instagram Reels: 9:16, 1080x1920, up to 90s",
      "TikTok: 9:16, 1080x1920, up to 10 min",
      "YouTube Shorts: 9:16, 1080x1920, up to 60s",
      "LinkedIn: 1:1 or 16:9, 1080p, up to 10 min",
      "Twitter/X: 16:9 or 1:1, 1080p, up to 2:20",
      "Facebook: 16:9, 1:1, or 9:16, 1080p, up to 240 min",
    ],
  },

  // === EVENT SUMMARIES ===
  {
    slug: "event-recap-structure",
    title: "Structuring a 2-Minute Event Recap",
    description:
      "How to distill a full-day event into a compelling 2-minute summary video. Shot planning, interview bites, and pacing.",
    category: "event-summary",
    level: "intermediate",
    phase: "pre-production",
    tags: ["planning", "structure", "pacing"],
    checklist: [
      "Open with energy — crowd or keynote moment",
      "Include 2-3 short interview soundbites (10-15s each)",
      "Show variety: wide shots, details, reactions",
      "End with a forward-looking statement or CTA",
      "Keep total runtime under 2:30",
    ],
    steps: [
      { title: "Plan your open", description: "Arrive early and capture the energy of setup, doors opening, or the first big moment." },
      { title: "Grab soundbites throughout", description: "Ask 5-8 attendees one simple question. You'll use 2-3 of the best." },
      { title: "Shoot the arc", description: "Beginning (arrival), middle (keynote/sessions), end (networking/closing). Tell the day's story." },
      { title: "Edit to music", description: "Choose an upbeat track and cut to the rhythm. Music drives pacing in recap videos." },
    ],
  },
  {
    slug: "event-run-and-gun",
    title: "Run-and-Gun Event Coverage",
    description:
      "Techniques for solo shooters covering live events with no second takes. Gear, settings, and workflow for one-person crews.",
    category: "event-summary",
    level: "intermediate",
    phase: "production",
    tags: ["solo-shooter", "live-events", "workflow"],
    checklist: [
      "Set camera to auto-ISO with exposure compensation",
      "Use a zoom lens (24-70mm or 24-105mm) to avoid lens changes",
      "Attach on-camera shotgun mic for ambient audio",
      "Shoot in 10-second bursts, not continuous",
      "Get wide establishing shots first, then details",
      "Charge batteries and format cards during breaks",
    ],
    equipment: ["Mirrorless camera", "24-70mm or 24-105mm zoom", "On-camera shotgun mic", "Monopod", "Extra batteries (4+)", "Multiple memory cards"],
  },
  {
    slug: "event-live-streaming",
    title: "Live Streaming an Event",
    description:
      "Set up a reliable live stream for corporate events. Covers encoding, redundancy, platform setup, and troubleshooting.",
    category: "event-summary",
    level: "advanced",
    phase: "production",
    tags: ["live-stream", "encoding", "technical"],
    checklist: [
      "Test internet upload speed (need 10Mbps+ for 1080p)",
      "Use wired ethernet, not WiFi",
      "Set up redundant encoder or backup stream",
      "Do a full dry run 24 hours before",
      "Have a dedicated stream operator (not the camera op)",
      "Prepare lower thirds and graphics in advance",
      "Set up monitoring on a separate device",
    ],
    equipment: ["Hardware encoder (e.g., Blackmagic ATEM Mini Pro)", "Ethernet cable (50ft+)", "Backup cellular bonding unit", "Dedicated streaming laptop", "Capture card"],
  },

  // === BROADCAST ===
  {
    slug: "broadcast-package-editing",
    title: "Editing a Broadcast News Package",
    description:
      "Professional workflow for assembling a 90-second broadcast package: track laying, SOTs, nat sound, and graphics.",
    category: "broadcast",
    level: "advanced",
    phase: "post-production",
    tags: ["editing", "broadcast", "workflow"],
    videoUrl: "https://www.youtube.com/embed/QGSJmOKaLJo",
    checklist: [
      "Lay narration track first",
      "Cut SOTs (sound on tape) to strongest bites",
      "Layer nat sound under narration at -12dB",
      "Add lower thirds and graphics",
      "Mix final audio to broadcast spec (-24 LUFS)",
      "Export in station-required format",
    ],
    equipment: ["NLE (Premiere Pro, Avid, DaVinci Resolve)", "Audio monitoring speakers"],
    steps: [
      { title: "Assemble the radio cut", description: "Lay narration and SOTs in order first. This is your story structure." },
      { title: "Cover with video", description: "Place B-roll over narration. Match visuals to what's being said." },
      { title: "Add nat sound", description: "Layer natural sound from B-roll clips at -12 to -18dB under narration for texture." },
      { title: "Graphics and lower thirds", description: "Add name supers on first appearance. Keep on screen for 4+ seconds." },
      { title: "Mix and master", description: "Check levels: narration at -12dB, SOTs at -12dB, nat sound at -18 to -24dB." },
    ],
  },
  {
    slug: "broadcast-standup",
    title: "Delivering a Strong Stand-Up",
    description:
      "The reporter stand-up bridges sections of your package. Learn blocking, delivery, and when to use a walking stand-up.",
    category: "broadcast",
    level: "beginner",
    phase: "production",
    tags: ["on-camera", "delivery", "reporting"],
    checklist: [
      "Choose a location that adds context to the story",
      "Frame medium shot with relevant background",
      "Memorize — don't read from notes",
      "Use natural hand gestures",
      "Deliver to the lens, not past it",
      "Record at least 3 takes",
    ],
    steps: [
      { title: "Choose your spot", description: "Stand where the background tells part of the story. Avoid generic walls or empty spaces." },
      { title: "Write tight", description: "Stand-ups should be 10-15 seconds. One clear thought, not a paragraph." },
      { title: "Practice out loud", description: "Say it 5 times before rolling. Your body language improves with each repetition." },
      { title: "Add movement (advanced)", description: "Walk toward camera or gesture to something in the scene to add energy." },
    ],
  },
  {
    slug: "broadcast-writing-for-video",
    title: "Writing Broadcast Copy",
    description:
      "Write narration that complements visuals rather than describing them. Broadcast writing rules for clarity and impact.",
    category: "broadcast",
    level: "intermediate",
    phase: "pre-production",
    tags: ["writing", "narration", "storytelling"],
    checklist: [
      "Write in present tense and active voice",
      "One idea per sentence",
      "Don't describe what viewers can see",
      "Lead with the 'so what' — why should they care?",
      "Use specific numbers and names",
      "Read aloud — if you stumble, rewrite",
    ],
  },

  // === VOICEOVER (additional) ===
  {
    slug: "voiceover-directing-talent",
    title: "Directing Voiceover Talent",
    description:
      "Get the read you need from VO artists. Communication techniques for remote and in-studio sessions.",
    category: "voiceover",
    level: "advanced",
    phase: "production",
    tags: ["directing", "talent", "communication"],
    checklist: [
      "Provide context: who's the audience, what's the tone?",
      "Give a reference (similar brand, specific adjectives)",
      "Direct with verbs: 'smile through this line' not 'be happier'",
      "Ask for 3 reads: safe, energetic, and their interpretation",
      "Give line reads only as a last resort",
      "Record a wild line or two for flexibility",
    ],
  },
];

export function getTipsByCategory(category: Category): Tip[] {
  return tips.filter((t) => t.category === category);
}

export function getTipsByLevel(level: SkillLevel): Tip[] {
  return tips.filter((t) => t.level === level);
}

export function getTipBySlug(slug: string): Tip | undefined {
  return tips.find((t) => t.slug === slug);
}

export function filterTips(filters: { category?: Category; level?: SkillLevel; search?: string }): Tip[] {
  return tips.filter((t) => {
    if (filters.category && t.category !== filters.category) return false;
    if (filters.level && t.level !== filters.level) return false;
    if (filters.search) {
      const q = filters.search.toLowerCase();
      return (
        t.title.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.tags.some((tag) => tag.toLowerCase().includes(q))
      );
    }
    return true;
  });
}

"use client";

import { useRef, useEffect } from "react";
import { Category, SkillLevel, CATEGORIES, LEVELS } from "@/lib/types";

interface FilterBarProps {
  selectedCategory: Category | null;
  selectedLevel: SkillLevel | null;
  searchQuery: string;
  onCategoryChange: (cat: Category | null) => void;
  onLevelChange: (level: SkillLevel | null) => void;
  onSearchChange: (query: string) => void;
}

export function FilterBar({
  selectedCategory,
  selectedLevel,
  searchQuery,
  onCategoryChange,
  onLevelChange,
  onSearchChange,
}: FilterBarProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const el = inputRef.current;
    if (!el) return;
    const handler = () => onSearchChange(el.value);
    el.addEventListener("input", handler);
    return () => el.removeEventListener("input", handler);
  }, [onSearchChange]);

  const handleCategoryClick = (e: React.MouseEvent, cat: Category | null) => {
    e.preventDefault();
    onCategoryChange(cat);
    setTimeout(() => {
      const target = cat ? `category-${cat}` : "tips-grid";
      document.getElementById(target)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 50);
  };

  const handleLevelClick = (e: React.MouseEvent, lvl: SkillLevel | null) => {
    e.preventDefault();
    onLevelChange(lvl);
    setTimeout(() => {
      const target = lvl ? `level-${lvl}` : "tips-grid";
      document.getElementById(target)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 50);
  };

  const activeStyle = { backgroundColor: 'var(--black)', color: 'var(--white)' };
  const inactiveStyle = { backgroundColor: 'var(--light-accent)', color: 'var(--black)' };

  return (
    <div className="space-y-4 mb-8">
      <div>
        <input
          ref={inputRef}
          type="text"
          placeholder="🔍 Search tips (e.g., lighting, audio, hook)..."
          defaultValue={searchQuery}
          className="w-full px-4 py-3 rounded-lg outline-none transition"
          style={{ border: '1px solid var(--light-accent)', fontFamily: 'Epilogue, sans-serif' }}
        />
      </div>
      <div>
        <h3 className="text-sm font-medium mb-2 opacity-60" style={{ fontFamily: 'Epilogue, sans-serif', textTransform: 'none' }}>Category</h3>
        <div className="flex flex-wrap gap-2">
          <a
            href="#tips-grid"
            onClick={(e) => handleCategoryClick(e, null)}
            className="px-3 py-1.5 rounded-full text-sm transition cursor-pointer select-none inline-block"
            style={!selectedCategory ? activeStyle : inactiveStyle}
          >
            All
          </a>
          {Object.entries(CATEGORIES).map(([key, { label, icon }]) => (
            <a
              key={key}
              href={`#category-${key}`}
              onClick={(e) => handleCategoryClick(e, key as Category)}
              className="px-3 py-1.5 rounded-full text-sm transition cursor-pointer select-none inline-block"
              style={selectedCategory === key ? activeStyle : inactiveStyle}
            >
              {icon} {label}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}

import Link from "next/link";
import { Tip, CATEGORIES, LEVELS } from "@/lib/types";

interface TipCardProps {
  tip: Tip;
  isLearned: boolean;
  onToggleLearn: (slug: string) => void;
}

export function TipCard({ tip, isLearned, onToggleLearn }: TipCardProps) {
  const category = CATEGORIES[tip.category];
  const level = LEVELS[tip.level];

  return (
    <div
      className="rounded-lg p-5 flex flex-col h-full transition-shadow hover:shadow-lg"
      style={{
        background: isLearned ? 'var(--light-accent)' : 'var(--white)',
        border: `1px solid ${isLearned ? 'var(--dark-accent)' : 'var(--light-accent)'}`,
      }}
    >
      <div className="flex items-center gap-2 mb-2">
        <span className="text-xl">{category.icon}</span>
        <span className="text-sm opacity-60">{category.label}</span>
        {tip.videoUrl && <span className="text-xs" title="Has video">▶️</span>}
        {tip.diagramUrl && <span className="text-xs" title="Has diagram">📐</span>}
        <span
          className="text-xs px-2 py-0.5 rounded-full ml-auto"
          style={{
            background: level.color.includes("green") ? "#d1fae5" : level.color.includes("yellow") ? "#fef3c7" : "#fce4ec",
            color: level.color.includes("green") ? "#065f46" : level.color.includes("yellow") ? "#92400e" : "#881337",
          }}
        >
          {level.label}
        </span>
      </div>
      <Link href={`/tips/${tip.slug}`} className="block flex-grow">
        <h3 className="text-lg mb-2 hover:opacity-70 transition" style={{ fontFamily: 'Epilogue, sans-serif', fontWeight: 600, textTransform: 'none' }}>{tip.title}</h3>
        <p className="text-sm opacity-70">{tip.description}</p>
      </Link>
      <div className="flex items-center justify-between mt-3 pt-3" style={{ borderTop: '1px solid var(--light-accent)' }}>
        <div className="flex flex-wrap gap-1">
          {tip.tags.slice(0, 3).map((tag) => (
            <span key={tag} className="text-xs px-2 py-0.5 rounded" style={{ background: 'var(--light-accent)' }}>
              {tag}
            </span>
          ))}
        </div>
        <button
          onClick={(e) => { e.preventDefault(); onToggleLearn(tip.slug); }}
          className="text-xs px-2 py-1 rounded transition"
          style={{
            background: isLearned ? 'var(--accent)' : 'var(--light-accent)',
            color: isLearned ? 'var(--black)' : 'var(--black)',
          }}
          title={isLearned ? "Mark as not learned" : "Mark as learned"}
        >
          {isLearned ? "✓ Learned" : "Mark learned"}
        </button>
      </div>
    </div>
  );
}
